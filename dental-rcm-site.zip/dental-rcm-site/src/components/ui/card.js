export const Card = ({ children }) => <div>{children}</div>;
export const CardContent = ({ children }) => <div>{children}</div>;